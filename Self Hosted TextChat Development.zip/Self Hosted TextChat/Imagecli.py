text = "This is the part after the colon: the rest of the sentence."
result = text.split(":")[1].strip()
print(result)